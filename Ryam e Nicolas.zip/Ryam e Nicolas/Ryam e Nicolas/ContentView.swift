
import SwiftUI
import Charts
import SwiftData

// MARK: - Modelo com SwiftData
@Model
class PomodoroSession {
    var date: Date
    var duration: Int // em minutos

    init(date: Date = Date(), duration: Int = 25) {
        self.date = date
        self.duration = duration
    }
}

// MARK: - View de Gráfico com Swift Charts
struct ChartView: View {
    @Query var sessions: [PomodoroSession]

    var groupedSessions: [(day: String, count: Int)] {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM"

        let grouped = Dictionary(grouping: sessions) { session in
            formatter.string(from: session.date)
        }

        return grouped
            .map { (key: String, value: [PomodoroSession]) in
                (day: key, count: value.count)
            }
            .sorted { $0.day < $1.day }
    }

    var body: some View {
        VStack(alignment: .leading) {
            Text("Sessões Pomodoro")
                .font(.headline)

            Chart {
                ForEach(groupedSessions, id: \.day) { entry in
                    BarMark(
                        x: .value("Dia", entry.day),
                        y: .value("Sessões", entry.count)
                    )
                    .foregroundStyle(.blue)
                }
            }
            .frame(height: 200)
            .padding()
        }
    }
}

// MARK: - View Principal para Teste
struct ContentView: View {
    @Environment(\.modelContext) private var context

    var body: some View {
        VStack {
            ChartView()

            Button("Adicionar Sessão") {
                let novaSessao = PomodoroSession()
                context.insert(novaSessao)
            }
            .padding()
            .buttonStyle(.borderedProminent)
        }
    }
}

// MARK: - Configuração do App com SwiftData
@main
struct PomodoroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: PomodoroSession.self)
    }
}
