//
//  Ryam_e_NicolasTests.swift
//  Ryam e NicolasTests
//
//  Created by iredefbmac_31 on 20/06/25.
//

import Testing
@testable import Ryam_e_Nicolas

struct Ryam_e_NicolasTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
